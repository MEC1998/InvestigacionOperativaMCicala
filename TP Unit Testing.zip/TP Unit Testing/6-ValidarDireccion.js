function validarDireccion(direccion) {
    if (typeof direccion.street !== 'string' || direccion.street.trim() === '') {
        return false;
    }

    if (typeof direccion.number !== 'number') {
        return false;
    }

    if (typeof direccion.zip_code !== 'number') {
        return false;
    }

    if (typeof direccion.city !== 'string' || direccion.city.trim() === '') {
        return false;
    }

    if (typeof direccion.province !== 'string' || direccion.province.trim() === '') {
        return false;
    }

    if (direccion.floor_apartment && typeof direccion.floor_apartment !== 'string') {
        return false;
    }

    if (direccion.town && typeof direccion.town !== 'string') {
        return false;
    }

    return true;
}

module.exports = validarDireccion;