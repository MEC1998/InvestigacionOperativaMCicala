const validarPIN = require("./1-ValidarCodigoPIN");

test("PIN válido de 4 dígitos (1234) debe retornar true", () => {
    expect(validarPIN("1234")).toBe(true);
});

test("PIN válido de 6 dígitos (123456) debe retornar true", () => {
    expect(validarPIN("123456")).toBe(true);
});

test("PIN de 3 dígitos (123) debe retornar false", () => {
    expect(validarPIN("123")).toBe(false);
});

test("PIN de 7 dígitos (1234567) debe retornar false", () => {
    expect(validarPIN("1234567")).toBe(false);
});

test("PIN con letras (12a4) debe retornar false", () => {
    expect(validarPIN("12a4")).toBe(false);
});

test("PIN vacío (\"\") debe retornar false", () => {
    expect(validarPIN("")).toBe(false);
});

test("PIN con caracteres especiales (12#4) debe retornar false", () => {
    expect(validarPIN("12#4")).toBe(false);
});
