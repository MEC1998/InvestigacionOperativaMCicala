const gruposSanguineos = [
    { grupo: "A+", puedeDonarA: ["A+", "AB+"], puedeRecibirDe: ["A+", "A-", "O+", "O-"] },
    { grupo: "A-", puedeDonarA: ["A+", "A-", "AB+", "AB-"], puedeRecibirDe: ["A-", "O-"] },
    { grupo: "B+", puedeDonarA: ["B+", "AB+"], puedeRecibirDe: ["B+", "B-", "O+", "O-"] },
    { grupo: "B-", puedeDonarA: ["B+", "B-", "AB+", "AB-"], puedeRecibirDe: ["B-", "O-"] },
    { grupo: "AB+", puedeDonarA: ["AB+"], puedeRecibirDe: ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"] },
    { grupo: "AB-", puedeDonarA: ["AB+", "AB-"], puedeRecibirDe: ["A-", "B-", "AB-", "O-"] },
    { grupo: "O+", puedeDonarA: ["O+", "A+", "B+", "AB+"], puedeRecibirDe: ["O+", "O-"] },
    { grupo: "O-", puedeDonarA: ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"], puedeRecibirDe: ["O-"] }
];

function obtenerGrupoAleatorio() {
    const indiceAleatorio = Math.floor(Math.random() * gruposSanguineos.length);
    return gruposSanguineos[indiceAleatorio];
}

function compararRespuestas(correcta, respuestaAlumno) {
    return correcta.sort().join() === respuestaAlumno.sort().join();
}

module.exports = { obtenerGrupoAleatorio, compararRespuestas };
