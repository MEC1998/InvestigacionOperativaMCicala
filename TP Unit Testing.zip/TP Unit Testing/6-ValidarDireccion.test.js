const validarDireccion = require('./6-ValidarDireccion');

test('Dirección válida debe pasar la validación', () => {
const direccion = {
    street: "Salta",
    number: 359,
    floor_apartment: "D3",
    zip_code: 5500,
    town: "",
    city: "Mendoza",
    province: "Mendoza"
};
expect(validarDireccion(direccion)).toBe(true);
});

test('Dirección sin número debe fallar la validación', () => {
const direccion = {
    street: "Salta",
    zip_code: 5500,
    city: "Mendoza",
    province: "Mendoza"
};
expect(validarDireccion(direccion)).toBe(false);
});

test('Dirección sin ciudad debe fallar la validación', () => {
const direccion = {
    street: "Salta",
    number: 359,
    zip_code: 5500,
    province: "Mendoza"
};
expect(validarDireccion(direccion)).toBe(false);
});

test('Dirección sin calle debe fallar la validación', () => {
const direccion = {
    number: 359,
    zip_code: 5500,
    city: "Mendoza",
    province: "Mendoza"
};
expect(validarDireccion(direccion)).toBe(false);
});

test('Dirección con un valor incorrecto en zip_code (string en lugar de número) debe fallar', () => {
const direccion = {
    street: "Salta",
    number: 359,
    zip_code: "5500",
    city: "Mendoza",
    province: "Mendoza"
};
expect(validarDireccion(direccion)).toBe(false);
});