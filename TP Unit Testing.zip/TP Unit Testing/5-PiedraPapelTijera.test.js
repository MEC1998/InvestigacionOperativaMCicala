const piedraPapelTijeras = require('./5-PiedraPapelTijera');

test('jugador 1 juega tijera, jugador 2 juega papel, jugador 1 gana', () => {
    expect(piedraPapelTijeras('tijera', 'papel')).toBe('jugador 1 gana!');
});

test('jugador 1 juega papel, jugador 2 juega piedra, jugador 1 gana', () => {
    expect(piedraPapelTijeras('papel', 'piedra')).toBe('jugador 1 gana!');
});

test('jugador 1 juega piedra, jugador 2 juega tijera, jugador 1 gana', () => {
    expect(piedraPapelTijeras('piedra', 'tijera')).toBe('jugador 1 gana!');
});

test('jugador 1 juega tijera, jugador 2 juega piedra, jugador 2 gana', () => {
    expect(piedraPapelTijeras('tijera', 'piedra')).toBe('jugador 2 gana!');
});

test('jugador 1 juega piedra, jugador 2 juega piedra, es un empate', () => {
    expect(piedraPapelTijeras('piedra', 'piedra')).toBe('empate!');
});

