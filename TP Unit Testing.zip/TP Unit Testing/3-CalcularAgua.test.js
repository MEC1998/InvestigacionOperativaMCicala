const calcularAgua = require('./3-CalcularAgua');

test('Franco pedalea 3 horas, debe tomar 1 litro de agua', () => {
    expect(calcularAgua(3)).toBe(1);
});

test('Franco pedalea 6.7 horas, debe tomar 3 litros de agua', () => {
    expect(calcularAgua(6.7)).toBe(3);
});

test('Franco pedalea 11.8 horas, debe tomar 5 litros de agua', () => {
    expect(calcularAgua(11.8)).toBe(5);
});

test('Franco pedalea 1 hora, debe tomar 0 litros de agua', () => {
    expect(calcularAgua(1)).toBe(0);
});

test('Franco pedalea 8 horas, debe tomar 4 litros de agua', () => {
    expect(calcularAgua(8)).toBe(4);
});
