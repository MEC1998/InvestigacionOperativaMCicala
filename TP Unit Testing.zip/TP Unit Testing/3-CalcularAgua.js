function calcularAgua(tiempo) {
    return Math.floor(tiempo * 0.5);
}  

module.exports=calcularAgua;