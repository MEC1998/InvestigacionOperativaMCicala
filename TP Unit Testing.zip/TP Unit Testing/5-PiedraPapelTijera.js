function piedraPapelTijeras(jugador1, jugador2) {
    if (jugador1 === jugador2) {
        return "empate!";
    }

        if (
        (jugador1 === "tijera" && jugador2 === "papel") ||
        (jugador1 === "papel" && jugador2 === "piedra") ||
        (jugador1 === "piedra" && jugador2 === "tijera")
    ) {
        return "jugador 1 gana!";
    } else {
        return "jugador 2 gana!";
    }  }

    
module.exports = piedraPapelTijeras;