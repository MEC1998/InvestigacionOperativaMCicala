function calcularVolumenTanque(diametro, altura, unidades){
    const PI = Math.PI;

    if (unidades === "cm"){
        diametro = diametro/100;
        altura = altura/100;
    }

    const radio = diametro/2;
    const volumenMetrosCubicos = PI*Math.pow(radio,2)*altura;

    const volumenLitros = volumenMetrosCubicos*1000;

    return volumenLitros;
}

module.exports = calcularVolumenTanque;