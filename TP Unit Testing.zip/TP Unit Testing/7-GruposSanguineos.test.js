const { obtenerGrupoAleatorio, compararRespuestas } = require('./7-GruposSanguineos');

test('obtenerGrupoAleatorio debe devolver un grupo sanguíneo válido', () => {
    const grupo = obtenerGrupoAleatorio();
    const gruposValidos = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
    expect(gruposValidos).toContain(grupo.grupo);
});

test('compararRespuestas debe devolver true para respuestas correctas', () => {
    const respuestaCorrecta = ["A+", "A-", "O+", "O-"];
    const respuestaAlumno = ["O-", "A+", "A-", "O+"];
    expect(compararRespuestas(respuestaCorrecta, respuestaAlumno)).toBe(true);
});

test('compararRespuestas debe devolver false para respuestas incorrectas', () => {
    const respuestaCorrecta = ["A+", "A-", "O+", "O-"];
    const respuestaAlumno = ["B+", "B-"];
    expect(compararRespuestas(respuestaCorrecta, respuestaAlumno)).toBe(false);
});

test('Cada grupo debe tener donantes y receptores definidos', () => {
    const grupo = obtenerGrupoAleatorio();
    expect(grupo.puedeDonarA).toBeDefined();
    expect(grupo.puedeRecibirDe).toBeDefined();
});

test('compararRespuestas debe devolver true cuando ambas respuestas son exactamente iguales', () => {
    const respuestaCorrecta = ["A+", "A-", "O+", "O-"];
    const respuestaAlumno = ["A+", "A-", "O+", "O-"];
    expect(compararRespuestas(respuestaCorrecta, respuestaAlumno)).toBe(true);
});