function validarPIN(pin){
    const pinRegex = /^(\d{4}|\d{6})$/;
    return pinRegex.test(pin);
}

module.exports = validarPIN;