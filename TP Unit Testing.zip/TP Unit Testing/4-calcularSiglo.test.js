const calcularSiglo = require("./4-CalcularSiglo");

test("El año 1705 corresponde al siglo 18", ()=>{
    expect(calcularSiglo(1705)).toBe(18);
});

test("El año 1900 corresponde al siglo 19", ()=>{
    expect(calcularSiglo(1900)).toBe(19);
});

test("El año 1601 corresponde al siglo 17", ()=>{
    expect(calcularSiglo(1601)).toBe(17);
});

test("El año 2000 corresponde al siglo 20", ()=>{
    expect(calcularSiglo(2000)).toBe(20);
});

test("El año 1 corresponde al siglo 1", ()=>{
    expect(calcularSiglo(1)).toBe(1);
});