const { default: expect } = require("expect");
const calcularVolumenTanque = require("./2-VolumenTanqueDeAgua");

test("Volumen con diámetro de 1m y altura de 1m debe ser 785,398 litros",()=>{
    expect(calcularVolumenTanque(1,1,"m")).toBeCloseTo(785.398, 3);
});

test("Volumen con diámetro de 100cm y altura de 100cm debe ser 785,398 litros", ()=>{
    expect(calcularVolumenTanque(100,100,"cm")).toBeCloseTo(785.398, 3);
});

test("Volumen con diámetro de 0,5m y altura de 2m debe ser 392,699 litros", ()=>{
    expect(calcularVolumenTanque(0.5,2,"m")).toBeCloseTo(392.699,3);
});

test("Volumen con diámetro de 50cm y altura de 200cm debe ser 392,699 litros", ()=>{
    expect(calcularVolumenTanque(50,200,"cm")).toBeCloseTo(392.699,3);
});

test("Volumen con diámetro de 2m y altura de 1m debe ser 3141,593 litros", ()=>{
    expect(calcularVolumenTanque(2,1,"m")).toBeCloseTo(3141.593,3);
});