function calcularSiglo(año){
    return Math.ceil(año/100);
}

module.exports = calcularSiglo;